// ProjectTwo.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>

#include "CSVparser.hpp"

using namespace std;

const unsigned int DEFAULT_SIZE = 179;

    
struct Course {
    string courseId;
    string courseName;
    vector<string> prerequisites;
    };
class HashTable {
private:
    
    // Define structures to hold courses
    struct Node {
        Course course;
        unsigned int key;
        Node* next;

        // default constructor
        Node() {
            key = UINT_MAX;
            next = nullptr;
        }
        // initialize with a course
        Node(Course aCourse) : Node() {
            course = aCourse;
        }

            // initialize with a course and a key
            Node(Course aCourse, unsigned int aKey) : Node(aCourse) {
                key = aKey;
            }
        };

        vector<Node> nodes;

        unsigned int tableSize = DEFAULT_SIZE;

        unsigned int hash(int key);
public:
        HashTable();
        virtual ~HashTable();
        void Insert(Course course);
        void PrintAll();
        Course Search(string courseId);
    };

    //constructor
    HashTable::HashTable() {
        //Initialize the structures used to hold courses
        nodes.resize(tableSize);
    }


    //Destructor
    HashTable::~HashTable() {
        // erase nodes beginning
        nodes.erase(nodes.begin());
    }

    // returns a hash value for a given key.
    // Key is returned as an unsigned int to prevent negative index value.
    unsigned int HashTable::hash(int key) {
        // return key mod tableSize
        return key % tableSize;
    }

    //insert a course into a hashtable
    void HashTable::Insert(Course course) {
        // create the key for the given course
        string digitID = "";
        //iterate over courseId
        for (int i = 0; i < course.courseId.length(); i++) {
            //if character at i is a letter
            if (isalpha(course.courseId[i])) {
                //create int x equal to character at i
                int x = course.courseId[i];
                //subtract 64 to make x equal to characters location in the alphabet. (A - Z) == (1 - 26)
                x -= 64;
                //append to digitID as a string value
                digitID.append(to_string(x));
            }
            //if character at i is not a letter
            else {
                //create int x and assign value of character at i
                int x = course.courseId[i];
                //subract 48 from x so that when it is converted to a string value it will match it's int value. 
                //'1' == 49 == "49" so 49 - 48 == 1 == "1".
                x -= 48;
                //append to digitId as a string value
                digitID.append(to_string((x)));
            }
        }
        int key = hash(atoi(digitID.c_str()));
        // retrieve node using key
        Node* currNode = &(nodes.at(key));
        // if no entry found for the key
        if (currNode == nullptr) {
            // assign this node to the key position
            Node* newNode = new Node(course, key);
            nodes.insert(nodes.begin() + key, (*newNode));
        }
        else {
            // else if node is not used
            if (currNode->key == UINT_MAX) {
                //set currNode key and course to provided values and the next value to null
                currNode->key = key;
                currNode->course = course;
                currNode->next = nullptr;
            }
        }
    }

    //print all courses
    void HashTable::PrintAll() {
        // for node begin to end iterate
        Node* currNode;
        for (unsigned int i = 0; i < tableSize; i++) {
            currNode = &(nodes.at(i));
            //   if key not equal to UINT_MAX
            if (currNode->key != UINT_MAX) {
                // output key, courseID, title, amount and fund
                cout << currNode->course.courseId << "| " << currNode->course.courseName;
                if (currNode->course.prerequisites.size() > 0) {
                    cout << "| " << "Prerequisites: ";
                    for (int j = 0; j < currNode->course.prerequisites.size(); j++) {
                        cout << currNode->course.prerequisites.at(j);
                        if (j + 1 != currNode->course.prerequisites.size()) {
                            cout << ", ";
                        }
                    }
                }
            cout << endl;
            }
        }
    }

    //find a specific course and return it
    Course HashTable::Search(string courseId) {
        // create the key using courseId
        string digitID = "";
        //iterate over courseId to change letters to digits and append to digitId.
        for (int i = 0; i < courseId.length(); i++) {
            if (isalpha(courseId[i])) {
                int x = courseId[i];
                x -= 64;
                digitID.append(to_string(x));
            }
            //if not a letter, append number
            else {
                int x = courseId[i];
                x -= 48;
                digitID.append(to_string((x)));
            }
        }
        int key = hash(atoi(digitID.c_str()));
        Node* currNode = &(nodes.at(key));
        // if entry found for the key
        if (currNode != nullptr) {
            //return node course
            return currNode->course;
        }
        else {
            //initialize and return an empty course object
            Course course;
            return course;
        }
    }

    // display a single courses information
    void displayCourse(Course course) {
        cout << course.courseId << "| " << course.courseName;
        if (course.prerequisites.size() > 0) {
            cout << "| " << "Prerequisites: ";
            for (int i = 0; i < course.prerequisites.size(); i++) {
                cout << course.prerequisites.at(i);
                if (i + 1 != course.prerequisites.size()) {
                    cout << ", ";
                }
            }
        }
        cout << endl;
        return;
    }

    // load coarses into the table.
    void loadCourses(string csvPath, HashTable* hashTable) {
        cout << "Loading Course file " << csvPath << endl;

        // initialize the CSV Parser using the given path
        csv::Parser file = csv::Parser(csvPath);

        try {
            // loop to read rows of a CSV file
            for (unsigned int i = 0; i < file.rowCount(); i++) {

                // Create a data structure and add to the collection of courses
                Course course;
                course.courseId = file[i][0];
                course.courseName = file[i][1];
                int j = 2;
                while (j != 4 && !file[i][j].empty() ) {
                    course.prerequisites.push_back(file[i][j]);
                    j++;
                }

                // push this course to the end
                hashTable->Insert(course);
            }
        }
        catch (csv::Error& e) {
            std::cerr << e.what() << std::endl;
        }
    }


    int main(int argc, char* argv[]) {
        //create variables
        string csvPath, courseKey;
        Course course;
        HashTable* courseTable = new HashTable();

        int choice = 0;
        while (choice != 4) {
            cout << "Menu:" << endl;
            cout << "  1. Load Courses" << endl;
            cout << "  2. Print Course List" << endl;
            cout << "  3. Print a Course" << endl;
            cout << "  4. Exit" << endl;
            cout << "Enter a number(1-4): " << endl;
                cin >> choice;
                //error handling for non digit inputs
                while (cin.fail()) {
                    cout << "invalid input. Please select a number 1" << endl;
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cin >> choice;

                }

            switch (choice) {

            case 1:
                cout << "what is the file name?: " << endl;
                cin >> csvPath;
                // Complete the method call to load the courses
                loadCourses(csvPath, courseTable);
                break;

            case 2:
                //Print all courses
                courseTable->PrintAll();
                break;

            case 3:
                // find specific course
                cout << "What course do you want to view?: " << endl;
                cin >> courseKey;
                course = courseTable->Search(courseKey);
                //if course exists
                if (!course.courseId.empty()) {
                    //display course information
                    displayCourse(course);
                }
                //else display that course is not found
                else {
                    cout << "Course Id " << courseKey << " not found." << endl;
                }

                break;

            default:
                cout << choice << " is not a valid selection." << endl;
            }

        }

        cout << "Good bye." << endl;

        return 0;
    }

